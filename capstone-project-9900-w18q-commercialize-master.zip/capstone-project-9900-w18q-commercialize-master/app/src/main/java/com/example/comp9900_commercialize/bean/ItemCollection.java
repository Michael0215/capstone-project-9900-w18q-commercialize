package com.example.comp9900_commercialize.bean;

import android.graphics.Bitmap;

public class ItemCollection {
    public String id;
    public Bitmap icon;
    public String title;
    public Bitmap avatar;
    public String tv_contributor_name;
}
