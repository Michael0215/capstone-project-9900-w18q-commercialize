The group Commercialize has uploaded the final submission to capstone-project-9900-w18q-commercialize's GitHub classroom account on time.

Source code url:

https://github.com/unsw-cse-comp3900-9900-22T3/capstone-project-9900-w18q-commercialize/tree/master

Command to download source code:

git clone -b master https://github.com/unsw-cse-comp3900-9900-22T3/capstone-project-9900-w18q-commercialize.git

Tips:
User documentation/manual File(System Setup Documentation) is contained in the Final Report part eight, please read.





