package com.example.comp9900_commercialize;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.comp9900_commercialize.adapters.CollectionAdapter;
import com.example.comp9900_commercialize.adapters.CommentAdapter;
import com.example.comp9900_commercialize.adapters.FollowAdapter;
import com.example.comp9900_commercialize.adapters.SubscribeAdapter;
import com.example.comp9900_commercialize.bean.Collection;
import com.example.comp9900_commercialize.bean.Comment;
import com.example.comp9900_commercialize.bean.Follow;
import com.example.comp9900_commercialize.bean.ItemCollection;
import com.example.comp9900_commercialize.bean.Recipe;
import com.example.comp9900_commercialize.bean.itemComment;
import com.example.comp9900_commercialize.databinding.ActivityCommentDetailBinding;
import com.example.comp9900_commercialize.utilities.MacroDef;
import com.example.comp9900_commercialize.utilities.Preferences;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

public class CommentActivity extends AppCompatActivity {
    private ActivityCommentDetailBinding binding;
    private static final String TAG = "CommentActivity";
    //private List<itemComment> myCommentList;
    Comment myComment;
    private FirebaseUser user;
    private FirebaseFirestore db,fbs;
    private RecyclerView RCVlist;
    private Preferences preferences;
    private DatabaseReference reference;
    private List<itemComment> mData;
    String recipeId, publishEmail,username,date,avatar;
    String commentsInput;
    private CommentAdapter adapter;
    private Recipe recipeObj;
    private int commentNum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCommentDetailBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        RCVlist=binding.rcvAllComment;
        init();
        setListener();
        loadData();
    }

    private void updateCommentNum() {
        DocumentReference commentDocRef=db.collection("recipes").document(preferences.getString(MacroDef.KEY_RECIPE_ID));
        commentDocRef.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
              recipeObj=documentSnapshot.toObject(Recipe.class);
              recipeObj.setRecipeCommentsNum(commentNum);

                db.collection("recipes").document(preferences.getString(MacroDef.KEY_RECIPE_ID)).set(recipeObj).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Log.d(TAG,"successfully written!");
                        //System.out.println(commentNum+" 评论数已经被设置为了++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                    }
                });
            }
        });
    }


    private void loadData() {
        mData=new ArrayList<itemComment>();
        itemComment iC=new itemComment();
        //获取recipeId的的reference
        DocumentReference docRef=db.collection("comment").document(recipeId);
        //加载数据然后布局
        //    private List<itemComment> myCommentList;
        //    Comment myComment;
        docRef.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                myComment=documentSnapshot.toObject(Comment.class);
                if(myComment != null) {
                    Collections.reverse(myComment.commentList);
                    mData = myComment.commentList;
//                    System.out.println(mData.size());
                }
                showLinear();
            }
        });
    }
//d

    private void showLinear() {
        binding.progressBar.setVisibility(View.GONE);
        binding.tvLoading.setVisibility(View.GONE);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        RCVlist.setLayoutManager(layoutManager);
        //创建适配器
        adapter = new CommentAdapter(mData);
        //设置适配器
        RCVlist.setAdapter(adapter);
        initListener();

    }


    private void CommentMainFunc() {
        mData=new ArrayList<>();
        itemComment newComment=new itemComment();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = new Date(System.currentTimeMillis());
        newComment.setDate(simpleDateFormat.format(date));
        newComment.setComment(commentsInput);
        newComment.setUsername(preferences.getString(MacroDef.KEY_USERNAME));
        newComment.setAvatar(preferences.getString(MacroDef.KEY_AVATAR));
        DocumentReference docRef = db.collection("comment").document(recipeId);
        docRef.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                myComment = documentSnapshot.toObject(Comment.class);
                if (myComment!=null){
                    if(myComment.commentList != null){
                        myComment.commentList.add(newComment);
                        showToast("You comment something");
                        //onResume();
                        binding.ivAddComment.setText("");

                    }
                }else{
                    myComment=new Comment(newComment);
                    showToast("You comment something 1st");
                    binding.ivAddComment.setText("");
                    //onResume();
                }
                db.collection("comment").document(recipeId).set(myComment).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Log.d(TAG,"successfully written!");
                        commentNum=myComment.commentList.size();
                        updateCommentNum();
                        //System.out.println(commentNum+"++++++++++++++++++++++++++++++++++++++++++++++++++++++");

                    }
                });
                updateCommentNum();
//                recreate();
                refresh();
            }
        });

    }

    public void refresh(){
        startActivity(new Intent(this, CommentActivity.class));
        finish();
    }
    private void setListener() {
        binding.btCancel.setOnClickListener(view -> {
            onBackPressed();
        });
        binding.sendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                commentsInput = binding.ivAddComment.getText().toString();
                if (commentsInput.equals("")) {
                    showToast("You can't enter empty comment!");
                } else {
                    CommentMainFunc();
                }
            }

        });
    }



    private void init() {
        preferences = new Preferences(getApplicationContext());
        user = FirebaseAuth.getInstance().getCurrentUser();
        db = FirebaseFirestore.getInstance();
        recipeId = preferences.getString(MacroDef.KEY_RECIPE_ID);
        publishEmail = preferences.getString(MacroDef.KEY_EMAIL);

    }

    private void showToast(String message) {
        Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
    }

    private void initListener() {
        adapter.setOnItemClickListener(new CommentAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                binding.ivAddComment.setText("@" + mData.get(position).username + " ");
            }
        }) ;
    }
}