package com.example.comp9900_commercialize.bean;

import android.graphics.Bitmap;

public class ItemFollow {
    public String id;
    public Bitmap avatar;
    public String tv_contributor_name;
}
