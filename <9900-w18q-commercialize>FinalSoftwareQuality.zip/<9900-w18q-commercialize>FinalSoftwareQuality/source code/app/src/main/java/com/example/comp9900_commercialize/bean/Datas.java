package com.example.comp9900_commercialize.bean;

import com.example.comp9900_commercialize.R;

public class Datas {
    public static int[] icons = {
            R.mipmap.pic_01,
            R.mipmap.pic_02,
            R.mipmap.pic_03,
            R.mipmap.pic_04,
            R.mipmap.pic_05,
            R.mipmap.pic_06,
            R.mipmap.pic_07,
            R.mipmap.pic_08,
            R.mipmap.pic_09,
            R.mipmap.pic_10,
            R.mipmap.pic_11,
            R.mipmap.pic_12,
            R.mipmap.pic_13,
            R.mipmap.pic_14,
            R.mipmap.pic_15,
            R.mipmap.pic_16,
            R.mipmap.pic_17,
            R.mipmap.pic_18,
            R.mipmap.pic_19,
            R.mipmap.pic_20
    };
}
