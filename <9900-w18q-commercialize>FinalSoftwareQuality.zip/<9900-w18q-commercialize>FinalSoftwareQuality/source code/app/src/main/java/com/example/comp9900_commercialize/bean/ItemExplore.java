package com.example.comp9900_commercialize.bean;

import android.graphics.Bitmap;

public class ItemExplore {
    public String id;
    public Bitmap icon;
    public String title;
    public int icon_like;
    public String tv_like_num;
    public int icon_comment;
    public String tv_comment_num;
//    public int avatar;
    public Bitmap avatar;
    public String tv_contributor_name;


}
