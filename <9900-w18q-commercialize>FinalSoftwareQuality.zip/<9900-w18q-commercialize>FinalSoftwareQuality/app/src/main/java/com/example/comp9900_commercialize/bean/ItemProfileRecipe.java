package com.example.comp9900_commercialize.bean;

import android.graphics.Bitmap;

public class ItemProfileRecipe {
    public String id;
    public Bitmap icon;
    public String title;

}
